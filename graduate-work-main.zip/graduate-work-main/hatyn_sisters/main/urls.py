from django.urls import path

app_name = 'main'

urlpatterns = [
    #path('', ProductsListView.as_view(), name='index')
]
